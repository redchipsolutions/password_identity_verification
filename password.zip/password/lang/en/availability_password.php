<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Availability password - Language pack
 *
 * @package    availability_password
 * @copyright  2016 Davo Smith, Synergy Learning UK on behalf of Alexander Bias, University of Ulm <alexander.bias@uni-ulm.de>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['description'] = 'Require students to enter a password.';

$string['enterpassword'] = 'What is your favorite color?';
$string['enterpassword_accident'] = 'How many people were in the car at the time of the accident, including you?';

$string['enterpasswordfor'] = 'Enter password for {$a}';
$string['error_setpassword'] = 'You must specify a password';
$string['password:addinstance'] = 'Add password conditions to activities';
$string['passwordintro'] = 'To access the Final Quiz, please answer the Identity Verification Questions. Your answers must match the answers provided while registering.<br/>
You have 1 minute to answer (30 seconds per question)!';
$string['permanently'] = 'Permanently';
$string['pluginname'] = 'Restriction by password';
$string['rememberpassword'] = 'Remember password entered';
$string['requires_password'] = 'You answer the Identity Verification Questions';
$string['requires_nopassword'] = 'You have not entered the correct password';
$string['title'] = 'Verification Code';
$string['untillogout'] = 'Until the user logs out';
$string['wrongpassword'] = 'Unfortunately you didn’t pass the Identity Verification!
You are not allowed to continue with the Online Course, and it will remain locked for you.
<br/><br/>
In order to avoid a negative identity verification report sent to the court, you have to attend our Classroom Course (no additional charge). Please contact us as soon as possible at administration@expressdd.com or 480-430-0408 to schedule it. Keep in mind that you have to take the class at least 7 days before your court date!';



