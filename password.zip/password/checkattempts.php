<?php

define('AJAX_SCRIPT', true);

require_once(dirname(__FILE__).'/../../../config.php');
global $PAGE;

$cmid = required_param('id', PARAM_INT);

/** @var cm_info $cm */
list($course, $cm) = get_course_and_cm_from_cmid($cmid);

$url = new moodle_url('/availability/condition/password/checkattempts.php', array('id' => $cm->id));
$PAGE->set_url($url);

require_login($course, false);
require_sesskey();

$ret = (object) [
    'error' => 0,
    'success' => 0,
];

if (\availability_password\condition::checkattempts($cm)) {
    $ret->success = 1;
}

echo json_encode($ret);
die();

?>